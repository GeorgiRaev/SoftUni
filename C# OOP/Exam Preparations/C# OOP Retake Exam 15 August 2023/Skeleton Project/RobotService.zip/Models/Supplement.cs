﻿using RobotService.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Models
{
    public abstract class Supplement : ISupplement
    {
        public int InterfaceStandard => throw new NotImplementedException();

        public int BatteryUsage => throw new NotImplementedException();
    }
}
