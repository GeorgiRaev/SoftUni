﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChristmasPastryShop.Core
{
    internal class Controller
    {
    }
}
