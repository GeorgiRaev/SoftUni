﻿namespace VehiclesExtension.Core.Interfaces;

public interface IEngine
{
    void Run();
}