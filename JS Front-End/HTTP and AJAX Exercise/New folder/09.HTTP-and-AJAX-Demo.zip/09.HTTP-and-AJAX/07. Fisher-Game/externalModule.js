const calculate = (a, b) => a + b;

export default calculate;
