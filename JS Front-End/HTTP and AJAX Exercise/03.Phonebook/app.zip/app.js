function attachEvents() {
    document.getElementById("btnLoad").addEventListener("click", loadContacts);
    document.getElementById("btnCreate").addEventListener("click", createContact);

    function loadContacts() {
        fetch("http://localhost:3030/jsonstore/phonebook")
            .then(response => response.json())
            .then(data => {
                const phonebook = document.getElementById("phonebook");
                phonebook.innerHTML = "";
                Object.values(data).forEach(contact => {
                    const li = document.createElement("li");
                    li.textContent = `${contact.person}: ${contact.phone}`;
                    phonebook.appendChild(li);
                });
            })
            .catch(error => console.error("Error:", error));
    }

    function createContact() {
        const person = document.getElementById("person").value;
        const phone = document.getElementById("phone").value;

        fetch("http://localhost:3030/jsonstore/phonebook", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ person, phone })
        })
            .then(response => response.json())
            .then(data => {
                console.log(data);
                loadContacts(); // Reload contacts after creating a new one
            })
            .catch(error => console.error("Error:", error));
    }

}

attachEvents();