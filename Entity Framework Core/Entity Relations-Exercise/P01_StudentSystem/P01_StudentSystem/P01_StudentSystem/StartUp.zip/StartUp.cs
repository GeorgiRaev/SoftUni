﻿using P01_StudentSystem.Data;

public class Startup
{
    public static void Main()
    {
        using (var context = new StudentSystemContext())
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
        }

        Console.WriteLine("Database created successfully!");
    }
}