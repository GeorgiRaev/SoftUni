﻿public enum CategoryType
{
    ADR,
    Filters,
    Lights,
    Others,
    Tyres
}