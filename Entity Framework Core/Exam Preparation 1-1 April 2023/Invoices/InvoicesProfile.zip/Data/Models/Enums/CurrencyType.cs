﻿public enum CurrencyType
{
    BGN,
    EUR,
    USD
}