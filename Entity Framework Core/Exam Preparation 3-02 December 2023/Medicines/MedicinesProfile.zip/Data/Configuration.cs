﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
