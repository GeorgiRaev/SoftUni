﻿using System;

class Program
{
    static void Main()
    {
        int[] dimensions = ReadIntArray();
        int n = dimensions[0];
        int m = dimensions[1];

        char[][] field = new char[n][];
        int startRow = -1;
        int startCol = -1;

        for (int i = 0; i < n; i++)
        {
            field[i] = Console.ReadLine().ToCharArray();
            for (int j = 0; j < m; j++)
            {
                if (field[i][j] == 'B')
                {
                    startRow = i;
                    startCol = j;
                }
            }
        }

        string commands = Console.ReadLine();
        int pizzaRow = -1;
        int pizzaCol = -1;

        foreach (var command in commands)
        {
            int newRow = startRow;
            int newCol = startCol;

            switch (command)
            {
                case 'U':
                    newRow--;
                    break;
                case 'D':
                    newRow++;
                    break;
                case 'L':
                    newCol--;
                    break;
                case 'R':
                    newCol++;
                    break;
            }

            if (!IsInBounds(newRow, newCol, n, m) || field[newRow][newCol] == '*')
            {
                Console.WriteLine("The delivery is late. Order is canceled.");
                break;
            }

            if (field[newRow][newCol] == 'P')
            {
                field[startRow][startCol] = '.';
                field[newRow][newCol] = 'B';
                startRow = newRow;
                startCol = newCol;
                pizzaRow = newRow;
                pizzaCol = newCol;
            }
            else if (field[newRow][newCol] == 'A')
            {
                field[startRow][startCol] = '.';
                field[newRow][newCol] = 'B';
                startRow = newRow;
                startCol = newCol;
                field[pizzaRow][pizzaCol] = '.';
                Console.WriteLine("Pizza is delivered on time! Next order...");
            }
            else
            {
                field[startRow][startCol] = '.';
                field[newRow][newCol] = 'B';
                startRow = newRow;
                startCol = newCol;
            }
        }

        PrintMatrix(field);
    }

    static int[] ReadIntArray()
    {
        string[] tokens = Console.ReadLine().Split();
        int[] array = new int[tokens.Length];
        for (int i = 0; i < tokens.Length; i++)
        {
            array[i] = int.Parse(tokens[i]);
        }
        return array;
    }

    static bool IsInBounds(int row, int col, int rows, int cols)
    {
        return row >= 0 && row < rows && col >= 0 && col < cols;
    }

    static void PrintMatrix(char[][] matrix)
    {
        foreach (var row in matrix)
        {
            Console.WriteLine(string.Join("", row));
        }
    }
}
